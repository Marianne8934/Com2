# SIMCOFI · Fase II · Incisos 1 y 2

Este paquete implementa solamente las partes solicitadas:

1. Simulacion de adquisicion y acondicionamiento con condiciones normales y de alarma.
2. Comparacion academica de AM correcta, sobremodulacion y sistema digital LoRa/CSS.

## Arquitectura

| Funcion | Puerto |
|---|---|
| Nodo 1 transmisor con todos los sensores simulados | COM8 |
| Estacion central receptora y graficas | COM7 |

El firmware transmisor y receptor ya cargado en las dos Heltec no necesita modificarse.

## Variables simuladas

- Fuente logica 1: temperatura ambiental y humedad (DHT22).
- Fuente logica 2: temperatura del producto y puerta (DS18B20 + reed switch).
- Fuente logica 3: temperatura de refrigeracion y corriente del compresor (DS18B20 + ACS712).

El rango normal de temperatura se considera de 2 a 8 grados Celsius. Se activa alarma de puerta cuando permanece abierta mas de 30 segundos. El compresor se considera activo a partir de 0.50 A.

## Instalacion

1. Cierra los dos monitores serie de PlatformIO.
2. Ejecuta `INSTALAR.bat` una sola vez.
3. Confirma que ambas Heltec tienen conectada una antena de 915 MHz.
4. Ejecuta `INICIAR_INTERFACES.bat`.

Tambien se pueden abrir manualmente dos terminales:

```powershell
py monitor_central.py
py simulador_nodo1.py
```

## Orden de uso

1. En la interfaz de la estacion central, presiona `Conectar COM7`.
2. En la interfaz del simulador, presiona `Conectar COM8`.
3. Presiona `Enviar ahora` para la primera comprobacion.
4. Deja activada la opcion de envio automatico cada dos minutos.
5. Cambia los sliders o usa los botones de escenario normal/alarma.
6. Observa las graficas de la estacion central; cada punto procede de una trama recibida por LoRa.

El monitor guarda automaticamente los datos en la carpeta `resultados`. Tambien permite exportar el CSV y guardar las graficas como imagen PNG.

## Comparacion AM y LoRa

La temperatura ambiental se modela como:

```text
T(t) = T_centro + 1.5 sen(2*pi*f_m*t)
```

Despues del acondicionamiento se normaliza la componente variable y se utiliza como senal moduladora:

```text
s_AM(t) = [1 + m*m_T(t)] cos(2*pi*f_c*t)
```

- Para `m = 0.50`, la envolvente no cruza cero y puede recuperarse sin distorsion con un detector de envolvente.
- Para `m = 1.20`, la envolvente cruza cero y aparece sobremodulacion y distorsion.
- LoRa convierte las mediciones a datos digitales y las transmite con chirps CSS; no representa el valor del sensor mediante la envolvente de amplitud.

