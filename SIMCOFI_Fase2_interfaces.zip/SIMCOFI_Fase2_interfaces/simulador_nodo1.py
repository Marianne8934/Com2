#!/usr/bin/env python3
"""Interfaz de simulacion del Nodo 1 de SIMCOFI.

Incisos implementados de la Fase II:
1. Adquisicion/acondicionamiento simulado, normal y alarma.
2. Comparacion academica AM correcta, sobremodulacion y CSS-LoRa.

La aplicacion envia una trama por COM8 cada 120 segundos. El firmware de la
Heltec transmite esa trama por LoRa hacia la estacion central conectada a COM7.
"""

from __future__ import annotations

import math
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import matplotlib

matplotlib.use("TkAgg")
import numpy as np
import serial
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from serial import SerialException


PUERTO_TX = "COM8"
BAUDIOS = 115200
INTERVALO_ENVIO_S = 120

TEMP_MIN_SEGURA = 2.0
TEMP_MAX_SEGURA = 8.0
PUERTA_MAX_S = 30.0
UMBRAL_COMPRESOR_A = 0.50

DESCRIPCION_ALARMA = {
    0: "Normal",
    1: "Temperatura mayor que 8 °C",
    2: "Temperatura menor que 2 °C",
    3: "Puerta abierta durante más de 30 s",
    4: "Temperatura alta con compresor inactivo",
    5: "Lectura inválida",
}


def alarma_temperatura(temperatura_c: float) -> int:
    if not math.isfinite(temperatura_c):
        return 5
    if temperatura_c > TEMP_MAX_SEGURA:
        return 1
    if temperatura_c < TEMP_MIN_SEGURA:
        return 2
    return 0


def alarma_acceso(temperatura_c: float, puerta: int, tiempo_s: float) -> int:
    codigo = alarma_temperatura(temperatura_c)
    if codigo:
        return codigo
    if puerta == 1 and tiempo_s > PUERTA_MAX_S:
        return 3
    return 0


def alarma_refrigeracion(temperatura_c: float, compresor: int) -> int:
    if not math.isfinite(temperatura_c):
        return 5
    if temperatura_c > TEMP_MAX_SEGURA and compresor == 0:
        return 4
    return alarma_temperatura(temperatura_c)


def construir_trama(valores: dict[str, float | int], secuencia: int) -> tuple[str, tuple[int, int, int]]:
    compresor = int(float(valores["I"]) >= UMBRAL_COMPRESOR_A)
    a1 = alarma_temperatura(float(valores["TA"]))
    a2 = alarma_acceso(
        float(valores["TP"]), int(valores["P"]), float(valores["PA"])
    )
    a3 = alarma_refrigeracion(float(valores["TR"]), compresor)

    trama = (
        f"N1|S={secuencia}"
        f"|TA={float(valores['TA']):.1f}"
        f"|HR={float(valores['HR']):.1f}"
        f"|TP={float(valores['TP']):.1f}"
        f"|P={int(valores['P'])}"
        f"|PA={float(valores['PA']):.0f}"
        f"|TR={float(valores['TR']):.1f}"
        f"|I={float(valores['I']):.2f}"
        f"|C={compresor}"
        f"|A1={a1:04b}"
        f"|A2={a2:04b}"
        f"|A3={a3:04b}"
    )
    return trama, (a1, a2, a3)


class SimuladorNodo1:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("SIMCOFI - Simulador del Nodo 1 (COM8)")
        self.root.geometry("1180x780")
        self.root.minsize(1040, 700)

        self.serial: serial.Serial | None = None
        self.buffer_serial = ""
        self.secuencia = 0
        self.proximo_envio = time.monotonic() + INTERVALO_ENVIO_S

        self.variables: dict[str, tk.DoubleVar | tk.IntVar] = {
            "TA": tk.DoubleVar(value=5.0),
            "HR": tk.DoubleVar(value=60.0),
            "TP": tk.DoubleVar(value=5.0),
            "P": tk.IntVar(value=0),
            "PA": tk.DoubleVar(value=0.0),
            "TR": tk.DoubleVar(value=5.0),
            "I": tk.DoubleVar(value=2.40),
        }
        self.textos_valor: dict[str, tk.StringVar] = {}
        self.auto_var = tk.BooleanVar(value=True)
        self.estado_serial = tk.StringVar(value="Desconectado de COM8")
        self.cuenta_regresiva = tk.StringVar(value="Próximo envío: --")
        self.ultima_trama = tk.StringVar(value="Todavía no se ha enviado ninguna trama.")
        self.texto_acondicionamiento = tk.StringVar()

        self._configurar_estilo()
        self._construir_interfaz()
        self.actualizar_estado()

        self.root.after(100, self.leer_respuestas_seriales)
        self.root.after(250, self.temporizador)
        self.root.protocol("WM_DELETE_WINDOW", self.cerrar)

    def _configurar_estilo(self) -> None:
        estilo = ttk.Style()
        try:
            estilo.theme_use("clam")
        except tk.TclError:
            pass
        estilo.configure("Titulo.TLabel", font=("Segoe UI", 17, "bold"))
        estilo.configure("Subtitulo.TLabel", font=("Segoe UI", 10))
        estilo.configure("Card.TLabelframe", padding=10)
        estilo.configure("Card.TLabelframe.Label", font=("Segoe UI", 10, "bold"))
        estilo.configure("Enviar.TButton", font=("Segoe UI", 10, "bold"))

    def _construir_interfaz(self) -> None:
        encabezado = ttk.Frame(self.root, padding=(14, 10))
        encabezado.pack(fill="x")
        ttk.Label(encabezado, text="SIMCOFI · Fase II", style="Titulo.TLabel").pack(side="left")
        ttk.Label(
            encabezado,
            text="Nodo 1 simulado → COM8 → LoRa → estación central COM7",
            style="Subtitulo.TLabel",
        ).pack(side="left", padx=18)

        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        self.tab_adquisicion = ttk.Frame(notebook, padding=12)
        self.tab_am = ttk.Frame(notebook, padding=10)
        notebook.add(self.tab_adquisicion, text="1. Adquisición y alarmas")
        notebook.add(self.tab_am, text="2. Comparación AM y LoRa")

        self._construir_tab_adquisicion()
        self._construir_tab_am()

    def _crear_slider(
        self,
        padre: ttk.Widget,
        fila: int,
        clave: str,
        titulo: str,
        minimo: float,
        maximo: float,
        formato: str,
    ) -> None:
        ttk.Label(padre, text=titulo).grid(row=fila, column=0, sticky="w", pady=6)
        escala = ttk.Scale(
            padre,
            from_=minimo,
            to=maximo,
            variable=self.variables[clave],
            command=lambda _valor: self.actualizar_estado(),
        )
        escala.grid(row=fila, column=1, sticky="ew", padx=10, pady=6)
        texto = tk.StringVar()
        self.textos_valor[clave] = texto
        ttk.Label(padre, textvariable=texto, width=10, anchor="e").grid(
            row=fila, column=2, sticky="e"
        )
        texto.set(formato.format(float(self.variables[clave].get())))

    def _construir_tab_adquisicion(self) -> None:
        self.tab_adquisicion.columnconfigure(0, weight=3)
        self.tab_adquisicion.columnconfigure(1, weight=2)
        self.tab_adquisicion.rowconfigure(0, weight=1)

        controles = ttk.Frame(self.tab_adquisicion)
        controles.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        controles.columnconfigure(0, weight=1)

        ambiente = ttk.LabelFrame(
            controles, text="Fuente lógica 1 · DHT22 (ambiente)", style="Card.TLabelframe"
        )
        ambiente.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ambiente.columnconfigure(1, weight=1)
        self._crear_slider(ambiente, 0, "TA", "Temperatura ambiental", -5, 15, "{:.1f} °C")
        self._crear_slider(ambiente, 1, "HR", "Humedad relativa", 0, 100, "{:.1f} %")

        acceso = ttk.LabelFrame(
            controles,
            text="Fuente lógica 2 · DS18B20 + reed switch (acceso)",
            style="Card.TLabelframe",
        )
        acceso.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        acceso.columnconfigure(1, weight=1)
        self._crear_slider(acceso, 0, "TP", "Temperatura del producto", -5, 15, "{:.1f} °C")
        ttk.Checkbutton(
            acceso,
            text="Puerta abierta",
            variable=self.variables["P"],
            command=self.actualizar_estado,
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=6)
        self._crear_slider(acceso, 2, "PA", "Tiempo de puerta abierta", 0, 120, "{:.0f} s")

        refrigeracion = ttk.LabelFrame(
            controles,
            text="Fuente lógica 3 · DS18B20 + ACS712 (refrigeración)",
            style="Card.TLabelframe",
        )
        refrigeracion.grid(row=2, column=0, sticky="ew", pady=(0, 8))
        refrigeracion.columnconfigure(1, weight=1)
        self._crear_slider(refrigeracion, 0, "TR", "Temperatura de refrigeración", -5, 15, "{:.1f} °C")
        self._crear_slider(refrigeracion, 1, "I", "Corriente del compresor", 0, 10, "{:.2f} A")

        escenarios = ttk.LabelFrame(controles, text="Escenarios de validación", padding=8)
        escenarios.grid(row=3, column=0, sticky="ew")
        for columna in range(5):
            escenarios.columnconfigure(columna, weight=1)
        botones = [
            ("Normal", "normal"),
            ("Temp. alta", "alta"),
            ("Temp. baja", "baja"),
            ("Puerta", "puerta"),
            ("Falla comp.", "compresor"),
        ]
        for columna, (texto, escenario) in enumerate(botones):
            ttk.Button(
                escenarios,
                text=texto,
                command=lambda e=escenario: self.aplicar_escenario(e),
            ).grid(row=0, column=columna, padx=3, sticky="ew")

        panel = ttk.Frame(self.tab_adquisicion)
        panel.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        panel.columnconfigure(0, weight=1)

        alarmas = ttk.LabelFrame(panel, text="Estado acondicionado", padding=10)
        alarmas.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        alarmas.columnconfigure(0, weight=1)
        self.etiquetas_alarma: list[tk.Label] = []
        nombres = ["A1 · Ambiente", "A2 · Acceso", "A3 · Refrigeración"]
        for fila, nombre in enumerate(nombres):
            etiqueta = tk.Label(
                alarmas,
                text=f"{nombre}: Normal",
                bg="#18794e",
                fg="white",
                font=("Segoe UI", 10, "bold"),
                padx=8,
                pady=8,
                anchor="w",
            )
            etiqueta.grid(row=fila, column=0, sticky="ew", pady=3)
            self.etiquetas_alarma.append(etiqueta)
        ttk.Label(
            alarmas,
            textvariable=self.texto_acondicionamiento,
            wraplength=390,
            justify="left",
        ).grid(row=3, column=0, sticky="ew", pady=(8, 0))

        comunicacion = ttk.LabelFrame(panel, text="Comunicación serial", padding=10)
        comunicacion.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        comunicacion.columnconfigure(0, weight=1)
        ttk.Label(comunicacion, textvariable=self.estado_serial).grid(row=0, column=0, sticky="w")
        ttk.Label(comunicacion, textvariable=self.cuenta_regresiva).grid(row=1, column=0, sticky="w", pady=4)

        botones_serial = ttk.Frame(comunicacion)
        botones_serial.grid(row=2, column=0, sticky="ew", pady=6)
        botones_serial.columnconfigure(0, weight=1)
        botones_serial.columnconfigure(1, weight=1)
        self.boton_conectar = ttk.Button(
            botones_serial, text="Conectar COM8", command=self.alternar_conexion
        )
        self.boton_conectar.grid(row=0, column=0, padx=(0, 4), sticky="ew")
        self.boton_enviar = ttk.Button(
            botones_serial,
            text="Enviar ahora",
            command=self.enviar_trama,
            state="disabled",
            style="Enviar.TButton",
        )
        self.boton_enviar.grid(row=0, column=1, padx=(4, 0), sticky="ew")
        ttk.Checkbutton(
            comunicacion,
            text="Envío automático cada 2 minutos",
            variable=self.auto_var,
            command=self.reiniciar_temporizador,
        ).grid(row=3, column=0, sticky="w")

        trama = ttk.LabelFrame(panel, text="Última trama / respuesta", padding=10)
        trama.grid(row=2, column=0, sticky="nsew")
        panel.rowconfigure(2, weight=1)
        ttk.Label(
            trama,
            textvariable=self.ultima_trama,
            wraplength=390,
            justify="left",
        ).pack(fill="both", expand=True)

    def _construir_tab_am(self) -> None:
        self.tab_am.rowconfigure(0, weight=1)
        self.tab_am.columnconfigure(0, weight=1)

        self.figura_am = Figure(figsize=(10.5, 6.4), dpi=100, constrained_layout=True)
        self.ejes_am = self.figura_am.subplots(2, 2)
        self.canvas_am = FigureCanvasTkAgg(self.figura_am, master=self.tab_am)
        self.canvas_am.get_tk_widget().grid(row=0, column=0, sticky="nsew")

        pie = ttk.Frame(self.tab_am, padding=(4, 8))
        pie.grid(row=1, column=0, sticky="ew")
        pie.columnconfigure(0, weight=1)
        ttk.Label(
            pie,
            text=(
                "Variable moduladora: temperatura ambiental acondicionada. "
                "AM transporta la información en la envolvente; LoRa digitaliza los datos "
                "y los representa mediante chirps, por lo que no depende de una envolvente AM."
            ),
            wraplength=900,
            justify="left",
        ).grid(row=0, column=0, sticky="w")
        ttk.Button(pie, text="Guardar gráfica PNG", command=self.guardar_grafica_am).grid(
            row=0, column=1, padx=8
        )

    def obtener_valores(self) -> dict[str, float | int]:
        return {
            "TA": float(self.variables["TA"].get()),
            "HR": float(self.variables["HR"].get()),
            "TP": float(self.variables["TP"].get()),
            "P": int(self.variables["P"].get()),
            "PA": float(self.variables["PA"].get()),
            "TR": float(self.variables["TR"].get()),
            "I": float(self.variables["I"].get()),
        }

    def actualizar_estado(self) -> None:
        formatos = {
            "TA": "{:.1f} °C",
            "HR": "{:.1f} %",
            "TP": "{:.1f} °C",
            "PA": "{:.0f} s",
            "TR": "{:.1f} °C",
            "I": "{:.2f} A",
        }
        for clave, formato in formatos.items():
            if clave in self.textos_valor:
                self.textos_valor[clave].set(formato.format(float(self.variables[clave].get())))

        _, alarmas = construir_trama(self.obtener_valores(), self.secuencia)
        nombres = ["A1 · Ambiente", "A2 · Acceso", "A3 · Refrigeración"]
        for etiqueta, nombre, codigo in zip(self.etiquetas_alarma, nombres, alarmas):
            color = "#18794e" if codigo == 0 else "#c62828"
            etiqueta.configure(
                text=f"{nombre}: {DESCRIPCION_ALARMA[codigo]} (código {codigo})",
                bg=color,
            )

        corriente = float(self.variables["I"].get())
        voltaje_sensor = 2.5 + 0.185 * corriente
        voltaje_adc = voltaje_sensor * (2.0 / 3.0)
        self.texto_acondicionamiento.set(
            "Acondicionamiento: DHT22/DS18B20 escalados a °C y %HR; "
            f"ACS712 Vout={voltaje_sensor:.2f} V y VADC={voltaje_adc:.2f} V; "
            "reed switch convertido a estado digital 0/1."
        )

        if hasattr(self, "canvas_am"):
            self.actualizar_grafica_am()

    def aplicar_escenario(self, escenario: str) -> None:
        configuraciones = {
            "normal": {"TA": 5.0, "HR": 60.0, "TP": 5.0, "P": 0, "PA": 0.0, "TR": 5.0, "I": 2.40},
            "alta": {"TA": 10.0, "HR": 72.0, "TP": 9.5, "P": 0, "PA": 0.0, "TR": 9.0, "I": 2.80},
            "baja": {"TA": 0.0, "HR": 55.0, "TP": 0.5, "P": 0, "PA": 0.0, "TR": 1.0, "I": 2.10},
            "puerta": {"TA": 5.5, "HR": 68.0, "TP": 5.8, "P": 1, "PA": 45.0, "TR": 5.2, "I": 2.40},
            "compresor": {"TA": 5.0, "HR": 60.0, "TP": 5.0, "P": 0, "PA": 0.0, "TR": 10.0, "I": 0.10},
        }
        for clave, valor in configuraciones[escenario].items():
            self.variables[clave].set(valor)
        self.actualizar_estado()

    def actualizar_grafica_am(self) -> None:
        temperatura_central = float(self.variables["TA"].get())
        t = np.linspace(0.0, 4.0, 2500)
        fm = 1.0
        fc = 12.0
        variacion_c = 1.5

        temperatura = temperatura_central + variacion_c * np.sin(2 * np.pi * fm * t)
        moduladora = (temperatura - temperatura_central) / variacion_c
        portadora = np.cos(2 * np.pi * fc * t)
        am_correcta = (1.0 + 0.50 * moduladora) * portadora
        am_sobre = (1.0 + 1.20 * moduladora) * portadora

        t_chirp = np.linspace(0.0, 1.0, 1800)
        fase_chirp = 2 * np.pi * (2.0 * t_chirp + 0.5 * 22.0 * t_chirp**2)
        chirp = np.cos(fase_chirp)

        for eje in self.ejes_am.flat:
            eje.clear()
            eje.grid(True, alpha=0.25)

        ax = self.ejes_am[0, 0]
        ax.plot(t, temperatura, color="#0b6e99", linewidth=1.8)
        ax.axhline(temperatura_central, color="gray", linestyle="--", linewidth=1)
        ax.set_title(f"Temperatura moduladora T(t), centro = {temperatura_central:.1f} °C")
        ax.set_ylabel("Temperatura [°C]")

        ax = self.ejes_am[0, 1]
        envolvente_05 = 1.0 + 0.50 * moduladora
        ax.plot(t, am_correcta, color="#2457c5", linewidth=0.8)
        ax.plot(t, envolvente_05, "r--", linewidth=1.2, label="Envolvente")
        ax.plot(t, -envolvente_05, "r--", linewidth=1.2)
        ax.set_title("AM correcta: índice m = 0.50")
        ax.set_ylim(-2.4, 2.4)
        ax.legend(loc="upper right")

        ax = self.ejes_am[1, 0]
        envolvente_12 = 1.0 + 1.20 * moduladora
        ax.plot(t, am_sobre, color="#7b2cbf", linewidth=0.8)
        ax.plot(t, envolvente_12, "r--", linewidth=1.2, label="Envolvente")
        ax.plot(t, -envolvente_12, "r--", linewidth=1.2)
        ax.fill_between(t, -2.4, 2.4, where=envolvente_12 < 0, color="red", alpha=0.12)
        ax.set_title("Sobremodulación: índice m = 1.20")
        ax.set_xlabel("Tiempo normalizado")
        ax.set_ylim(-2.4, 2.4)
        ax.legend(loc="upper right")

        ax = self.ejes_am[1, 1]
        ax.plot(t_chirp, chirp, color="#00856a", linewidth=1.0)
        ax.set_title("LoRa/CSS: chirp digital de amplitud casi constante")
        ax.set_xlabel("Duración normalizada de un símbolo")
        ax.set_ylabel("Amplitud")

        self.canvas_am.draw_idle()

    def guardar_grafica_am(self) -> None:
        ruta = filedialog.asksaveasfilename(
            title="Guardar comparación AM y LoRa",
            defaultextension=".png",
            filetypes=[("Imagen PNG", "*.png")],
            initialfile="comparacion_AM_LoRa.png",
        )
        if ruta:
            self.figura_am.savefig(ruta, dpi=180, bbox_inches="tight")
            messagebox.showinfo("SIMCOFI", f"Gráfica guardada en:\n{ruta}")

    def alternar_conexion(self) -> None:
        if self.serial and self.serial.is_open:
            self.desconectar()
            return
        try:
            self.serial = serial.Serial(
                PUERTO_TX,
                BAUDIOS,
                timeout=0,
                write_timeout=1,
            )
        except SerialException as error:
            messagebox.showerror(
                "No se pudo abrir COM8",
                f"{error}\n\nCierra el monitor serie de PlatformIO y vuelve a intentar.",
            )
            return

        self.estado_serial.set("Conectando con Nodo 1 en COM8…")
        self.boton_conectar.configure(text="Desconectar COM8")
        self.root.after(1700, self.conexion_lista)

    def conexion_lista(self) -> None:
        if self.serial and self.serial.is_open:
            self.serial.reset_input_buffer()
            self.estado_serial.set("Conectado: Nodo 1 transmisor en COM8")
            self.boton_enviar.configure(state="normal")
            self.reiniciar_temporizador()

    def desconectar(self) -> None:
        if self.serial:
            try:
                self.serial.close()
            except SerialException:
                pass
        self.serial = None
        self.estado_serial.set("Desconectado de COM8")
        self.boton_conectar.configure(text="Conectar COM8")
        self.boton_enviar.configure(state="disabled")
        self.cuenta_regresiva.set("Próximo envío: --")

    def reiniciar_temporizador(self) -> None:
        self.proximo_envio = time.monotonic() + INTERVALO_ENVIO_S

    def temporizador(self) -> None:
        if self.serial and self.serial.is_open and self.auto_var.get():
            restante = max(0, math.ceil(self.proximo_envio - time.monotonic()))
            minutos, segundos = divmod(restante, 60)
            self.cuenta_regresiva.set(f"Próximo envío: {minutos:02d}:{segundos:02d}")
            if restante <= 0:
                self.enviar_trama(automatico=True)
        elif self.serial and self.serial.is_open:
            self.cuenta_regresiva.set("Envío automático pausado")
        self.root.after(250, self.temporizador)

    def enviar_trama(self, automatico: bool = False) -> None:
        if not self.serial or not self.serial.is_open:
            if not automatico:
                messagebox.showwarning("SIMCOFI", "Primero conecta el Nodo 1 en COM8.")
            return

        trama, _alarmas = construir_trama(self.obtener_valores(), self.secuencia)
        try:
            self.serial.write((trama + "\n").encode("utf-8"))
            self.serial.flush()
        except SerialException as error:
            messagebox.showerror("Error serial", str(error))
            self.desconectar()
            return

        modo = "automático" if automatico else "manual"
        self.ultima_trama.set(f"Envío {modo}:\n{trama}")
        self.secuencia = (self.secuencia + 1) % 256
        self.reiniciar_temporizador()
        self.actualizar_estado()

    def leer_respuestas_seriales(self) -> None:
        if self.serial and self.serial.is_open:
            try:
                disponibles = self.serial.in_waiting
                if disponibles:
                    self.buffer_serial += self.serial.read(disponibles).decode(
                        "utf-8", errors="replace"
                    )
                    while "\n" in self.buffer_serial:
                        linea, self.buffer_serial = self.buffer_serial.split("\n", 1)
                        linea = linea.strip()
                        if linea:
                            self.ultima_trama.set(
                                f"Respuesta del transmisor:\n{linea}"
                            )
            except SerialException:
                self.desconectar()
        self.root.after(100, self.leer_respuestas_seriales)

    def cerrar(self) -> None:
        self.desconectar()
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    SimuladorNodo1(root)
    root.mainloop()


if __name__ == "__main__":
    main()
