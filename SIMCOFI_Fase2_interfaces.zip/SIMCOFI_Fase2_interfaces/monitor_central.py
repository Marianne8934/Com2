#!/usr/bin/env python3
"""Monitor en tiempo real de la estacion central SIMCOFI conectada a COM7."""

from __future__ import annotations

import csv
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import matplotlib

matplotlib.use("TkAgg")
import serial
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from serial import SerialException


PUERTO_RX = "COM7"
BAUDIOS = 115200
INTERVALO_ESPERADO_S = 120

CAMPOS_REQUERIDOS = {
    "S", "TA", "HR", "TP", "P", "PA", "TR", "I", "C", "A1", "A2", "A3", "RSSI", "SNR"
}

DESCRIPCION_ALARMA = {
    0: "Normal",
    1: "Temperatura alta",
    2: "Temperatura baja",
    3: "Puerta abierta > 30 s",
    4: "Temperatura alta / compresor inactivo",
    5: "Lectura inválida",
}


def convertir_alarma(texto: str) -> int:
    if texto and set(texto) <= {"0", "1"}:
        return int(texto, 2)
    return int(texto)


def analizar_linea(linea: str) -> dict[str, float | int] | None:
    if not linea.startswith("RX|N1|"):
        return None

    valores_texto: dict[str, str] = {}
    for elemento in linea.split("|")[2:]:
        if "=" in elemento:
            clave, valor = elemento.split("=", 1)
            valores_texto[clave.strip()] = valor.strip()

    if not CAMPOS_REQUERIDOS.issubset(valores_texto):
        return None

    return {
        "S": int(valores_texto["S"]),
        "TA": float(valores_texto["TA"]),
        "HR": float(valores_texto["HR"]),
        "TP": float(valores_texto["TP"]),
        "P": int(valores_texto["P"]),
        "PA": float(valores_texto["PA"]),
        "TR": float(valores_texto["TR"]),
        "I": float(valores_texto["I"]),
        "C": int(valores_texto["C"]),
        "A1": convertir_alarma(valores_texto["A1"]),
        "A2": convertir_alarma(valores_texto["A2"]),
        "A3": convertir_alarma(valores_texto["A3"]),
        "RSSI": float(valores_texto["RSSI"]),
        "SNR": float(valores_texto["SNR"]),
    }


class MonitorCentral:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("SIMCOFI - Estación central y gráficas en tiempo real (COM7)")
        self.root.geometry("1280x820")
        self.root.minsize(1080, 720)

        self.serial: serial.Serial | None = None
        self.buffer_serial = ""
        self.inicio_sesion = time.monotonic()
        self.datos: list[dict[str, float | int | str]] = []

        carpeta_resultados = Path(__file__).resolve().parent / "resultados"
        carpeta_resultados.mkdir(exist_ok=True)
        marca = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.ruta_csv = carpeta_resultados / f"recepcion_SIMCOFI_{marca}.csv"

        self.estado_serial = tk.StringVar(value="Desconectado de COM7")
        self.total_paquetes = tk.StringVar(value="Paquetes válidos: 0")
        self.ultima_recepcion = tk.StringVar(value="Última recepción: --")

        self._configurar_estilo()
        self._construir_interfaz()
        self.root.after(100, self.leer_serial)
        self.root.protocol("WM_DELETE_WINDOW", self.cerrar)

    def _configurar_estilo(self) -> None:
        estilo = ttk.Style()
        try:
            estilo.theme_use("clam")
        except tk.TclError:
            pass
        estilo.configure("Titulo.TLabel", font=("Segoe UI", 17, "bold"))
        estilo.configure("Dato.TLabel", font=("Segoe UI", 11, "bold"))

    def _construir_interfaz(self) -> None:
        encabezado = ttk.Frame(self.root, padding=(14, 10))
        encabezado.pack(fill="x")
        ttk.Label(encabezado, text="Estación central SIMCOFI", style="Titulo.TLabel").pack(side="left")
        ttk.Label(encabezado, textvariable=self.estado_serial).pack(side="left", padx=18)
        self.boton_conectar = ttk.Button(
            encabezado, text="Conectar COM7", command=self.alternar_conexion
        )
        self.boton_conectar.pack(side="right")

        resumen = ttk.Frame(self.root, padding=(12, 4))
        resumen.pack(fill="x")
        ttk.Label(resumen, textvariable=self.total_paquetes).pack(side="left")
        ttk.Label(resumen, textvariable=self.ultima_recepcion).pack(side="left", padx=20)
        ttk.Label(resumen, text="Periodo esperado: 2 minutos").pack(side="left")
        ttk.Button(resumen, text="Guardar gráfica PNG", command=self.guardar_grafica).pack(side="right")
        ttk.Button(resumen, text="Exportar CSV", command=self.exportar_csv).pack(side="right", padx=8)

        cuerpo = ttk.Frame(self.root, padding=12)
        cuerpo.pack(fill="both", expand=True)
        cuerpo.columnconfigure(0, weight=1)
        cuerpo.rowconfigure(1, weight=1)

        tarjetas = ttk.Frame(cuerpo)
        tarjetas.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        for columna in range(7):
            tarjetas.columnconfigure(columna, weight=1)

        self.valores_texto: dict[str, tk.StringVar] = {}
        tarjetas_info = [
            ("TA", "T. ambiente", "-- °C"),
            ("HR", "Humedad", "-- %"),
            ("TP", "T. producto", "-- °C"),
            ("TR", "T. refrigeración", "-- °C"),
            ("I", "Corriente", "-- A"),
            ("P", "Puerta", "--"),
            ("RF", "Enlace", "RSSI -- / SNR --"),
        ]
        for columna, (clave, titulo, inicial) in enumerate(tarjetas_info):
            marco = ttk.LabelFrame(tarjetas, text=titulo, padding=8)
            marco.grid(row=0, column=columna, padx=3, sticky="ew")
            variable = tk.StringVar(value=inicial)
            self.valores_texto[clave] = variable
            ttk.Label(marco, textvariable=variable, style="Dato.TLabel", anchor="center").pack(fill="x")

        zona_graficas = ttk.Frame(cuerpo)
        zona_graficas.grid(row=1, column=0, sticky="nsew")
        zona_graficas.rowconfigure(0, weight=1)
        zona_graficas.columnconfigure(0, weight=1)

        self.figura = Figure(figsize=(11.5, 6.2), dpi=100, constrained_layout=True)
        self.ejes = self.figura.subplots(2, 2)
        self.canvas = FigureCanvasTkAgg(self.figura, master=zona_graficas)
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew")
        self.actualizar_graficas()

        inferior = ttk.Frame(cuerpo)
        inferior.grid(row=2, column=0, sticky="ew", pady=(8, 0))
        inferior.columnconfigure(1, weight=1)

        alarmas = ttk.Frame(inferior)
        alarmas.grid(row=0, column=0, sticky="w")
        self.etiquetas_alarma: list[tk.Label] = []
        for columna, nombre in enumerate(("A1 Ambiente", "A2 Acceso", "A3 Refrigeración")):
            etiqueta = tk.Label(
                alarmas,
                text=f"{nombre}: --",
                bg="#5f6368",
                fg="white",
                font=("Segoe UI", 9, "bold"),
                padx=8,
                pady=6,
            )
            etiqueta.grid(row=0, column=columna, padx=3)
            self.etiquetas_alarma.append(etiqueta)

        self.registro = tk.Text(inferior, height=4, wrap="word", state="disabled")
        self.registro.grid(row=0, column=1, sticky="ew", padx=(10, 0))

    def escribir_registro(self, texto: str) -> None:
        hora = datetime.now().strftime("%H:%M:%S")
        self.registro.configure(state="normal")
        self.registro.insert("end", f"[{hora}] {texto}\n")
        self.registro.see("end")
        self.registro.configure(state="disabled")

    def alternar_conexion(self) -> None:
        if self.serial and self.serial.is_open:
            self.desconectar()
            return

        try:
            self.serial = serial.Serial(PUERTO_RX, BAUDIOS, timeout=0)
        except SerialException as error:
            messagebox.showerror(
                "No se pudo abrir COM7",
                f"{error}\n\nCierra el monitor serie de PlatformIO y vuelve a intentar.",
            )
            return

        self.estado_serial.set("Conectando con la estación central en COM7…")
        self.boton_conectar.configure(text="Desconectar COM7")
        self.root.after(1700, self.conexion_lista)

    def conexion_lista(self) -> None:
        if self.serial and self.serial.is_open:
            self.serial.reset_input_buffer()
            self.estado_serial.set("Conectado: estación central receptora en COM7")
            self.escribir_registro("COM7 abierto. Esperando paquetes LoRa del Nodo 1.")

    def desconectar(self) -> None:
        if self.serial:
            try:
                self.serial.close()
            except SerialException:
                pass
        self.serial = None
        self.estado_serial.set("Desconectado de COM7")
        self.boton_conectar.configure(text="Conectar COM7")

    def leer_serial(self) -> None:
        if self.serial and self.serial.is_open:
            try:
                disponibles = self.serial.in_waiting
                if disponibles:
                    self.buffer_serial += self.serial.read(disponibles).decode(
                        "utf-8", errors="replace"
                    )
                    while "\n" in self.buffer_serial:
                        linea, self.buffer_serial = self.buffer_serial.split("\n", 1)
                        linea = linea.strip()
                        if linea:
                            self.procesar_linea(linea)
            except SerialException as error:
                self.escribir_registro(f"Error serial: {error}")
                self.desconectar()
        self.root.after(100, self.leer_serial)

    def procesar_linea(self, linea: str) -> None:
        try:
            lectura = analizar_linea(linea)
        except (ValueError, TypeError) as error:
            self.escribir_registro(f"Trama inválida: {error}")
            return

        if lectura is None:
            self.escribir_registro(linea)
            return

        ahora = datetime.now()
        registro: dict[str, float | int | str] = {
            "fecha_hora": ahora.isoformat(timespec="seconds"),
            "minutos": (time.monotonic() - self.inicio_sesion) / 60.0,
            **lectura,
        }
        self.datos.append(registro)
        self.guardar_fila_csv(registro)
        self.actualizar_panel(lectura)
        self.actualizar_graficas()
        self.total_paquetes.set(f"Paquetes válidos: {len(self.datos)}")
        self.ultima_recepcion.set(f"Última recepción: {ahora.strftime('%H:%M:%S')}")
        self.escribir_registro(
            f"RX secuencia {lectura['S']} · RSSI {lectura['RSSI']:.1f} dBm · SNR {lectura['SNR']:.1f} dB"
        )

    def actualizar_panel(self, lectura: dict[str, float | int]) -> None:
        self.valores_texto["TA"].set(f"{lectura['TA']:.1f} °C")
        self.valores_texto["HR"].set(f"{lectura['HR']:.1f} %")
        self.valores_texto["TP"].set(f"{lectura['TP']:.1f} °C")
        self.valores_texto["TR"].set(f"{lectura['TR']:.1f} °C")
        self.valores_texto["I"].set(f"{lectura['I']:.2f} A")
        puerta = "ABIERTA" if int(lectura["P"]) else "CERRADA"
        self.valores_texto["P"].set(f"{puerta}\n{lectura['PA']:.0f} s")
        self.valores_texto["RF"].set(
            f"RSSI {lectura['RSSI']:.1f}\nSNR {lectura['SNR']:.1f}"
        )

        nombres = ("A1 Ambiente", "A2 Acceso", "A3 Refrigeración")
        for etiqueta, nombre, clave in zip(self.etiquetas_alarma, nombres, ("A1", "A2", "A3")):
            codigo = int(lectura[clave])
            etiqueta.configure(
                text=f"{nombre}: {DESCRIPCION_ALARMA.get(codigo, 'Código desconocido')}",
                bg="#18794e" if codigo == 0 else "#c62828",
            )

    def actualizar_graficas(self) -> None:
        for eje in self.ejes.flat:
            eje.clear()
            eje.grid(True, alpha=0.25)
            eje.set_xlabel("Tiempo desde el inicio [min]")

        ax_temp = self.ejes[0, 0]
        ax_temp.set_title("Temperaturas recibidas por LoRa")
        ax_temp.set_ylabel("Temperatura [°C]")
        ax_temp.axhspan(2, 8, color="green", alpha=0.08, label="Rango 2–8 °C")

        ax_hr = self.ejes[0, 1]
        ax_hr.set_title("Humedad relativa")
        ax_hr.set_ylabel("HR [%]")
        ax_hr.set_ylim(0, 100)

        ax_corriente = self.ejes[1, 0]
        ax_corriente.set_title("Corriente del compresor")
        ax_corriente.set_ylabel("Corriente [A]")
        ax_corriente.axhline(0.5, color="red", linestyle="--", linewidth=1, label="Umbral 0.5 A")

        ax_puerta = self.ejes[1, 1]
        ax_puerta.set_title("Estado de puerta")
        ax_puerta.set_ylabel("0 cerrada / 1 abierta")
        ax_puerta.set_ylim(-0.1, 1.1)
        ax_puerta.set_yticks([0, 1])

        if self.datos:
            x = [float(d["minutos"]) for d in self.datos]
            ax_temp.plot(x, [float(d["TA"]) for d in self.datos], "o-", label="Ambiente")
            ax_temp.plot(x, [float(d["TP"]) for d in self.datos], "s-", label="Producto")
            ax_temp.plot(x, [float(d["TR"]) for d in self.datos], "^-", label="Refrigeración")
            ax_hr.plot(x, [float(d["HR"]) for d in self.datos], "o-", color="#0b6e99")
            ax_corriente.plot(x, [float(d["I"]) for d in self.datos], "o-", color="#7b2cbf")
            ax_puerta.step(x, [int(d["P"]) for d in self.datos], where="post", color="#d97706")

        ax_temp.legend(loc="best", fontsize=8)
        ax_corriente.legend(loc="best", fontsize=8)
        self.canvas.draw_idle()

    @staticmethod
    def nombres_columnas() -> list[str]:
        return [
            "fecha_hora", "minutos", "S", "TA", "HR", "TP", "P", "PA", "TR", "I", "C",
            "A1", "A2", "A3", "RSSI", "SNR"
        ]

    def guardar_fila_csv(self, registro: dict[str, float | int | str]) -> None:
        nuevo = not self.ruta_csv.exists()
        with self.ruta_csv.open("a", newline="", encoding="utf-8") as archivo:
            escritor = csv.DictWriter(archivo, fieldnames=self.nombres_columnas())
            if nuevo:
                escritor.writeheader()
            escritor.writerow(registro)

    def exportar_csv(self) -> None:
        if not self.datos:
            messagebox.showwarning("SIMCOFI", "Todavía no se han recibido datos válidos.")
            return
        ruta = filedialog.asksaveasfilename(
            title="Exportar datos recibidos",
            defaultextension=".csv",
            filetypes=[("Archivo CSV", "*.csv")],
            initialfile="datos_recibidos_SIMCOFI.csv",
        )
        if not ruta:
            return
        with open(ruta, "w", newline="", encoding="utf-8") as archivo:
            escritor = csv.DictWriter(archivo, fieldnames=self.nombres_columnas())
            escritor.writeheader()
            escritor.writerows(self.datos)
        messagebox.showinfo("SIMCOFI", f"Datos guardados en:\n{ruta}")

    def guardar_grafica(self) -> None:
        ruta = filedialog.asksaveasfilename(
            title="Guardar gráficas de recepción",
            defaultextension=".png",
            filetypes=[("Imagen PNG", "*.png")],
            initialfile="graficas_tiempo_real_SIMCOFI.png",
        )
        if ruta:
            self.figura.savefig(ruta, dpi=180, bbox_inches="tight")
            messagebox.showinfo("SIMCOFI", f"Gráfica guardada en:\n{ruta}")

    def cerrar(self) -> None:
        self.desconectar()
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    MonitorCentral(root)
    root.mainloop()


if __name__ == "__main__":
    main()
