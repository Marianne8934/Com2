@echo off
title Instalar dependencias SIMCOFI
cd /d "%~dp0"
py -m pip install -r requirements.txt
echo.
echo Instalacion terminada.
pause

