@echo off
cd /d "%~dp0"
start "SIMCOFI - Central COM7" cmd /k py monitor_central.py
timeout /t 2 /nobreak >nul
start "SIMCOFI - Nodo 1 COM8" cmd /k py simulador_nodo1.py

