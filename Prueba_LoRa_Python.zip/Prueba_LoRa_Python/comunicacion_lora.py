import tkinter as tk
from tkinter import messagebox

import serial
from serial import SerialException


# =====================================================
# CONFIGURACIÓN SERIAL
# =====================================================
PUERTO_TRANSMISOR = "COM7"
PUERTO_RECEPTOR = "COM9"
VELOCIDAD = 115200


# =====================================================
# RANGOS DEL DHT22
# =====================================================
DHT22_TEMP_MIN = -40.0
DHT22_TEMP_MAX = 80.0

DHT22_HUM_MIN = 0.0
DHT22_HUM_MAX = 100.0


# =====================================================
# RANGO SEGURO DE TEMPERATURA PARA SIMCOFI
# =====================================================
TEMP_SEGURA_MIN = 2.0
TEMP_SEGURA_MAX = 8.0


# =====================================================
# BANDAS VISUALES DE HUMEDAD
# =====================================================
HUMEDAD_BAJA_MAX = 30.0
HUMEDAD_MEDIA_MAX = 70.0


# =====================================================
# COLORES
# =====================================================
COLOR_AZUL = "#2166C1"
COLOR_VERDE = "#2E8B57"
COLOR_ROJO = "#C62828"
COLOR_AMARILLO = "#B36B00"
COLOR_TEXTO = "#555555"


class SimuladorSIMCOFI:

    def __init__(self, ventana):

        self.ventana = ventana

        self.ventana.title(
            "SIMCOFI - Simulador del Nodo 1"
        )

        self.ventana.geometry("780x620")
        self.ventana.resizable(False, False)

        self.transmisor = None
        self.receptor = None

        self.puertos_listos = False
        self.secuencia = 0

        self.temperatura = tk.DoubleVar(
            value=5.0
        )

        self.humedad = tk.DoubleVar(
            value=60.0
        )

        self.crear_interfaz()
        self.actualizar_estados()
        self.abrir_puertos()

        self.ventana.after(
            50,
            self.leer_puertos
        )

        self.ventana.protocol(
            "WM_DELETE_WINDOW",
            self.cerrar_programa
        )

    # =================================================
    # CREAR INTERFAZ
    # =================================================
    def crear_interfaz(self):

        # ---------------------------------------------
        # TÍTULO
        # ---------------------------------------------
        tk.Label(
            self.ventana,
            text="SIMCOFI",
            font=("Arial", 24, "bold"),
            fg="#0B3954"
        ).pack(
            pady=(15, 0)
        )

        tk.Label(
            self.ventana,
            text=(
                "Simulación del Nodo 1 "
                "- Temperatura y humedad"
            ),
            font=("Arial", 13)
        ).pack(
            pady=(0, 12)
        )

        # ---------------------------------------------
        # COMUNICACIÓN LORA
        # ---------------------------------------------
        marco_comunicacion = tk.LabelFrame(
            self.ventana,
            text="Comunicación LoRa",
            font=("Arial", 11, "bold"),
            padx=10,
            pady=12
        )

        marco_comunicacion.pack(
            fill="x",
            padx=12,
            pady=5
        )

        # Solo se mostrará una línea.
        # Ya no se mostrará:
        # "Conectado: COM7 → LoRa → COM9"
        self.label_comunicacion = tk.Label(
            marco_comunicacion,
            text="Inicializando comunicación LoRa...",
            font=("Arial", 10),
            fg=COLOR_AMARILLO
        )

        self.label_comunicacion.pack()

        # ---------------------------------------------
        # TEMPERATURA SIMULADA
        # ---------------------------------------------
        marco_temperatura = tk.LabelFrame(
            self.ventana,
            text="Temperatura simulada",
            font=("Arial", 11, "bold"),
            padx=10,
            pady=8
        )

        marco_temperatura.pack(
            fill="x",
            padx=12,
            pady=6
        )

        self.label_temperatura = tk.Label(
            marco_temperatura,
            text="5.0 °C",
            font=("Arial", 19, "bold"),
            fg="#1D4E89"
        )

        self.label_temperatura.pack()

        self.slider_temperatura = tk.Scale(
            marco_temperatura,
            variable=self.temperatura,
            from_=DHT22_TEMP_MIN,
            to=DHT22_TEMP_MAX,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            length=700,
            showvalue=False,
            command=self.cambio_slider
        )

        self.slider_temperatura.pack(
            fill="x"
        )

        self.label_estado_temperatura = tk.Label(
            marco_temperatura,
            text="TEMPERATURA NORMAL",
            font=("Arial", 11, "bold"),
            fg="white",
            bg=COLOR_VERDE,
            padx=10,
            pady=6
        )

        self.label_estado_temperatura.pack(
            fill="x",
            pady=(4, 3)
        )

        tk.Label(
            marco_temperatura,
            text=(
                "DHT22: -40 a 80 °C | "
                "SIMCOFI: 2 a 8 °C"
            ),
            font=("Arial", 9),
            fg=COLOR_TEXTO
        ).pack()

        self.slider_temperatura.bind(
            "<ButtonRelease-1>",
            self.slider_liberado
        )

        # ---------------------------------------------
        # HUMEDAD SIMULADA
        # ---------------------------------------------
        marco_humedad = tk.LabelFrame(
            self.ventana,
            text="Humedad relativa simulada",
            font=("Arial", 11, "bold"),
            padx=10,
            pady=8
        )

        marco_humedad.pack(
            fill="x",
            padx=12,
            pady=6
        )

        self.label_humedad = tk.Label(
            marco_humedad,
            text="60.0 %RH",
            font=("Arial", 19, "bold"),
            fg="#0077B6"
        )

        self.label_humedad.pack()

        self.slider_humedad = tk.Scale(
            marco_humedad,
            variable=self.humedad,
            from_=DHT22_HUM_MIN,
            to=DHT22_HUM_MAX,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            length=700,
            showvalue=False,
            command=self.cambio_slider
        )

        self.slider_humedad.pack(
            fill="x"
        )

        self.label_estado_humedad = tk.Label(
            marco_humedad,
            text="HUMEDAD MEDIA",
            font=("Arial", 11, "bold"),
            fg="white",
            bg=COLOR_VERDE,
            padx=10,
            pady=6
        )

        self.label_estado_humedad.pack(
            fill="x",
            pady=(4, 3)
        )

        tk.Label(
            marco_humedad,
            text=(
                "DHT22: 0 a 100 %RH, "
                "resolución de 0.1 %RH"
            ),
            font=("Arial", 9),
            fg=COLOR_TEXTO
        ).pack()

        tk.Label(
            marco_humedad,
            text=(
                "Bandas visuales: "
                "0–30 baja | 30–70 media | 70–100 alta"
            ),
            font=("Arial", 9),
            fg="#9A5A00"
        ).pack()

        self.slider_humedad.bind(
            "<ButtonRelease-1>",
            self.slider_liberado
        )

        # ---------------------------------------------
        # ALARMA DE SIMCOFI
        # ---------------------------------------------
        marco_alarma = tk.LabelFrame(
            self.ventana,
            text="Alarma de SIMCOFI",
            font=("Arial", 11, "bold"),
            padx=10,
            pady=8
        )

        marco_alarma.pack(
            fill="x",
            padx=12,
            pady=6
        )

        self.label_alarma = tk.Label(
            marco_alarma,
            text="TEMPERATURA NORMAL - Código 0000",
            font=("Arial", 14, "bold"),
            fg="white",
            bg=COLOR_VERDE,
            padx=10,
            pady=8
        )

        self.label_alarma.pack(
            fill="x"
        )

        tk.Label(
            marco_alarma,
            text=(
                "La humedad se visualiza, "
                "pero no activa una alarma en la Fase 1."
            ),
            font=("Arial", 9),
            fg=COLOR_TEXTO
        ).pack(
            pady=(5, 0)
        )

    # =================================================
    # ESTADO DE TEMPERATURA
    # =================================================
    def obtener_estado_temperatura(self):

        temperatura = self.temperatura.get()

        if temperatura > TEMP_SEGURA_MAX:

            return (
                "0001",
                "TEMPERATURA ALTA",
                COLOR_ROJO
            )

        if temperatura < TEMP_SEGURA_MIN:

            return (
                "0010",
                "TEMPERATURA BAJA",
                COLOR_AZUL
            )

        return (
            "0000",
            "TEMPERATURA NORMAL",
            COLOR_VERDE
        )

    # =================================================
    # ESTADO DE HUMEDAD
    # =================================================
    def obtener_estado_humedad(self):

        humedad = self.humedad.get()

        if humedad <= HUMEDAD_BAJA_MAX:

            return (
                "HUMEDAD BAJA",
                COLOR_AZUL
            )

        if humedad <= HUMEDAD_MEDIA_MAX:

            return (
                "HUMEDAD MEDIA",
                COLOR_VERDE
            )

        return (
            "HUMEDAD ALTA",
            COLOR_ROJO
        )

    # =================================================
    # ACTUALIZAR ESTADOS EN PANTALLA
    # =================================================
    def actualizar_estados(self):

        temperatura = self.temperatura.get()
        humedad = self.humedad.get()

        (
            codigo,
            estado_temperatura,
            color_temperatura
        ) = self.obtener_estado_temperatura()

        (
            estado_humedad,
            color_humedad
        ) = self.obtener_estado_humedad()

        self.label_temperatura.config(
            text=f"{temperatura:.1f} °C"
        )

        self.label_humedad.config(
            text=f"{humedad:.1f} %RH"
        )

        self.label_estado_temperatura.config(
            text=estado_temperatura,
            bg=color_temperatura
        )

        self.label_estado_humedad.config(
            text=estado_humedad,
            bg=color_humedad
        )

        self.label_alarma.config(
            text=(
                f"{estado_temperatura} "
                f"- Código {codigo}"
            ),
            bg=color_temperatura
        )

    # =================================================
    # EVENTOS DE LOS SLIDERS
    # =================================================
    def cambio_slider(self, valor=None):

        self.actualizar_estados()

    def slider_liberado(self, evento=None):

        self.actualizar_estados()

        # Enviar automáticamente al soltar
        # cualquiera de los sliders.
        self.enviar_datos()

    # =================================================
    # ABRIR PUERTOS
    # =================================================
    def abrir_puertos(self):

        try:
            self.transmisor = serial.Serial(
                port=PUERTO_TRANSMISOR,
                baudrate=VELOCIDAD,
                timeout=0.05,
                write_timeout=2
            )

            self.receptor = serial.Serial(
                port=PUERTO_RECEPTOR,
                baudrate=VELOCIDAD,
                timeout=0.05,
                write_timeout=2
            )

            self.label_comunicacion.config(
                text="Inicializando comunicación LoRa...",
                fg=COLOR_AMARILLO
            )

            # Esperar tres segundos porque las placas
            # pueden reiniciarse al abrir los puertos.
            self.ventana.after(
                3000,
                self.finalizar_conexion
            )

        except SerialException as error:

            self.label_comunicacion.config(
                text="Error al establecer la comunicación",
                fg=COLOR_ROJO
            )

            messagebox.showerror(
                "Error de comunicación",
                (
                    "No se pudieron abrir los puertos.\n\n"
                    f"{error}\n\n"
                    "Verifica que:\n"
                    "- El transmisor sea COM7.\n"
                    "- El receptor sea COM9.\n"
                    "- Los monitores de PlatformIO estén cerrados."
                )
            )

    # =================================================
    # FINALIZAR CONEXIÓN
    # =================================================
    def finalizar_conexion(self):

        if self.transmisor is None:
            return

        if self.receptor is None:
            return

        try:
            self.transmisor.reset_input_buffer()
            self.receptor.reset_input_buffer()

            self.puertos_listos = True

            self.label_comunicacion.config(
                text=(
                    "Sistema listo. "
                    "Mueve cualquiera de los sliders."
                ),
                fg=COLOR_VERDE
            )

            # Enviar los valores iniciales.
            self.enviar_datos()

        except SerialException:

            self.label_comunicacion.config(
                text="Error al inicializar la comunicación",
                fg=COLOR_ROJO
            )

    # =================================================
    # ENVIAR TEMPERATURA Y HUMEDAD
    # =================================================
    def enviar_datos(self):

        if not self.puertos_listos:
            return

        temperatura = self.temperatura.get()
        humedad = self.humedad.get()

        (
            codigo,
            estado_temperatura,
            color
        ) = self.obtener_estado_temperatura()

        paquete = (
            f"N1"
            f"|S={self.secuencia}"
            f"|T={temperatura:.1f}"
            f"|H={humedad:.1f}"
            f"|A={codigo}"
        )

        try:
            self.transmisor.reset_input_buffer()
            self.receptor.reset_input_buffer()

            self.transmisor.write(
                (paquete + "\n").encode("utf-8")
            )

            self.transmisor.flush()

            self.label_comunicacion.config(
                text="Enviando temperatura y humedad...",
                fg=COLOR_AMARILLO
            )

            self.secuencia = (
                self.secuencia + 1
            ) % 256

        except SerialException:

            self.label_comunicacion.config(
                text="Error al enviar los datos",
                fg=COLOR_ROJO
            )

    # =================================================
    # LEER RESPUESTAS DE LOS LORA
    # =================================================
    def leer_puertos(self):

        try:
            # -----------------------------------------
            # LEER TRANSMISOR
            # -----------------------------------------
            if self.transmisor is not None:

                while self.transmisor.in_waiting > 0:

                    linea_tx = (
                        self.transmisor
                        .readline()
                        .decode(
                            "utf-8",
                            errors="replace"
                        )
                        .strip()
                    )

                    if linea_tx == "TX_OK":

                        self.label_comunicacion.config(
                            text=(
                                "Transmisión completada. "
                                "Esperando receptor..."
                            ),
                            fg=COLOR_VERDE
                        )

                    elif linea_tx == "TX_TIMEOUT":

                        self.label_comunicacion.config(
                            text="Tiempo de transmisión agotado",
                            fg=COLOR_ROJO
                        )

            # -----------------------------------------
            # LEER RECEPTOR
            # -----------------------------------------
            if self.receptor is not None:

                while self.receptor.in_waiting > 0:

                    linea_rx = (
                        self.receptor
                        .readline()
                        .decode(
                            "utf-8",
                            errors="replace"
                        )
                        .strip()
                    )

                    if linea_rx.startswith("RX|N1|"):

                        # Esta es la única línea que quedará
                        # normalmente en Comunicación LoRa.
                        self.label_comunicacion.config(
                            text=(
                                "Temperatura y humedad "
                                "mostradas en la OLED"
                            ),
                            fg=COLOR_VERDE
                        )

                    elif linea_rx == "RX_ERROR":

                        self.label_comunicacion.config(
                            text="Error de recepción LoRa",
                            fg=COLOR_ROJO
                        )

                    elif linea_rx == "RX_TIMEOUT":

                        self.label_comunicacion.config(
                            text="Tiempo de recepción agotado",
                            fg=COLOR_ROJO
                        )

        except SerialException:

            self.label_comunicacion.config(
                text="Se perdió la comunicación serial",
                fg=COLOR_ROJO
            )

        self.ventana.after(
            50,
            self.leer_puertos
        )

    # =================================================
    # CERRAR PROGRAMA
    # =================================================
    def cerrar_programa(self):

        try:
            if self.transmisor is not None:

                if self.transmisor.is_open:
                    self.transmisor.close()

            if self.receptor is not None:

                if self.receptor.is_open:
                    self.receptor.close()

        finally:
            self.ventana.destroy()


# =====================================================
# INICIAR PROGRAMA
# =====================================================
if __name__ == "__main__":

    ventana_principal = tk.Tk()

    aplicacion = SimuladorSIMCOFI(
        ventana_principal
    )

    ventana_principal.mainloop()